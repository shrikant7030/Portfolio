import image1 from "../assets/imagenew.jpg"


export const projectList = [
    {
        name:'Algorithm visualizer',
        image: image1
    },
    {
        name:'Algorithm initializer',
        image: image1
    },
    {
        name:'Algorithm fjsaldgjalsjg',
        image: image1
    }
]